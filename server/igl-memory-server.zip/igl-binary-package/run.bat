@echo off
cd /d "%~dp0"
if not defined IGL_DB_PATH set IGL_DB_PATH=.\data\igl.sqlite3
if not exist ".\data" mkdir ".\data"
igl-memory-server.exe
pause
