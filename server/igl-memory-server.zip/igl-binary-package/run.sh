#!/bin/bash
cd "$(dirname "$0")"
export IGL_DB_PATH="${IGL_DB_PATH:-./data/igl.sqlite3}"
mkdir -p "$(dirname "$IGL_DB_PATH")"
exec ./igl-memory-server
